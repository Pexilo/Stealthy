const mongoose = require("mongoose");

const guildSchema = new mongoose.Schema({
  id: String,
  language: { type: String, default: "en" },

  logs: {
    channel: { type: String, default: null },
    users: { type: Array, default: [] },
  },

  membercount: {
    channel: { type: String, default: null },
    name: { type: String, default: "👥 Members" },
  },

  roleclaim: {
    channel: { type: String, default: null },
    message: { type: String, default: null },
    tipMessage: { type: String, default: null },
    fields: { type: Array, default: [] },
  },

  autorole: {
    roles: { type: Array, default: [] },
  },

  blacklist: {
    time: { type: Number, default: 86400000 },
    minAge: { type: Number, default: 3600000 },
  },

  joinToCreate: {
    channel: { type: String, default: null },
    names: {
      type: Array,
      default: [
        "🗻 Everest",
        "🌉 San Francisco",
        "🌅 Bahamas",
        "💳 VIP Room",
        "🏰 Peach Castle",
      ],
    },
    activeChannels: { type: Array, default: [] },
  },
});

module.exports = mongoose.model("Guild", guildSchema);
